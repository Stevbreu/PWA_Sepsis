// PWA bootstrapping, tabs, calculators. No personal data is stored.
(function(){
  // Tabs
  const tabs = document.querySelectorAll('.tab');
  const panes = {
    akut: document.getElementById('pane-akut'),
    bundle: document.getElementById('pane-bundle'),
    vent: document.getElementById('pane-vent'),
    calc: document.getElementById('pane-calc'),
    qs: document.getElementById('pane-qs'),
    info: document.getElementById('pane-info'),
  };
  tabs.forEach(btn => btn.addEventListener('click', () => {
    tabs.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    Object.values(panes).forEach(p => p.classList.remove('active'));
    panes[btn.dataset.tab].classList.add('active');
    btn.setAttribute('aria-selected','true');
  }));

  // Install prompt
  let deferredPrompt = null;
  const installBtn = document.getElementById('btn-install');
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
  });
  installBtn.addEventListener('click', async () => {
    if(deferredPrompt){
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
    }else{
      alert('Nutze das Browser‑Menü → „Zum Startbildschirm hinzufügen“.');
    }
  });

  // Print
  document.getElementById('btn-print').addEventListener('click', () => window.print());

  // Service worker
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js');
    });
  }

  // Calculators
  // Fluid 30 ml/kg
  const kg = document.getElementById('kg'); const fluidOut = document.getElementById('fluid');
  document.getElementById('btn-fluid').addEventListener('click', () => {
    const w = parseFloat(kg.value || '0');
    const ml = Math.round(w * 30);
    fluidOut.textContent = isFinite(ml) ? ml : '–';
  });

  // Lactate clearance
  const l0 = document.getElementById('l0'); const l1 = document.getElementById('l1');
  document.getElementById('btn-lac').addEventListener('click', () => {
    const a = parseFloat(l0.value || '0'); const b = parseFloat(l1.value || '0');
    const delta = +(b - a).toFixed(2);
    const pct = a>0 ? Math.round((a - b)/a * 100) : 0;
    document.getElementById('lac-delta').textContent = delta;
    document.getElementById('lac-pct').textContent = pct;
  });

  // MAP delta
  const mapIn = document.getElementById('map');
  document.getElementById('btn-map').addEventListener('click', () => {
    const cur = parseFloat(mapIn.value || '0');
    const d = Math.max(0, Math.round(65 - cur));
    document.getElementById('map-delta').textContent = d;
  });

  // IBW & tidal volume (Devine formula; height in cm)
  document.getElementById('btn-ibw').addEventListener('click', () => {
    const sex = document.getElementById('sex').value;
    const cm = parseFloat(document.getElementById('cm').value || '0');
    if(!cm || cm < 120){ document.getElementById('ibw').textContent = '–'; return; }
    const base = (sex === 'm') ? 50.0 : 45.5;
    const ibw = +(base + 0.9 * (cm - 152)).toFixed(1); // kg
    const vt6 = Math.round(6 * ibw);
    const vt4 = Math.round(4 * ibw);
    const vt8 = Math.round(8 * ibw);
    document.getElementById('ibw').textContent = ibw;
    document.getElementById('vt6').textContent = vt6;
    document.getElementById('vt48').textContent = vt4 + '–' + vt8;
  });
})();